<!--Iyad Shobaki
    FALL 2018 WEB DEV WITH PHP AND MYSQL
    Professor  Kathy Ison
    GuidedAcivity_Lab Week 4
    9/19/2018 -->

<?php
//Includes activity
$page_title = 'Welcome to My Wonderful PHP Site!';

include('includes/header.html');

?>
<div class="page-header"><h1>Content Header</h1></div>
<p>This is where the page-specific content goes. This section, and the corresponding header, will change from one page to the next.</p>

<!--some dummy text-->
<p>Volutpat at varius sed sollioitudin et, arou. Vivamus viverra.Nullam turpis. Vestibulum sed etiam. Lorem ipsun sit anet dolore. Nulla facilist. Sed tortor. Aenean felis. Sed egestas, ante et vulputate volutpat, eros pede semper est, vitae luctus metus libero eu augue. Morbi purus libero, faucibus adipiscing, commodo quis, gravida id, est. Sed lectus</p>
<p>Volutpat at varius sed sollioitudin et, arou. Vivamus viverra.Nullam turpis. Vestibulum sed etiam. Lorem ipsun sit anet dolore. Nulla facilist. Sed tortor. Aenean felis. Sed egestas, ante et vulputate volutpat, eros pede semper est, vitae luctus metus libero eu augue. Morbi purus libero, faucibus adipiscing, commodo quis, gravida id, est. Sed lectus</p>

<?php
include ('includes/footer.html');
?>